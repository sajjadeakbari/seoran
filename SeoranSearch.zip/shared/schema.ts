import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Table for crawled pages
export const crawledPages = pgTable("crawled_pages", {
  id: text("id").primaryKey(),
  url: text("url").notNull().unique(),
  title: text("title"),
  content: text("content"),
  description: text("description"),
  language: text("language").default("fa"),
  indexedAt: timestamp("indexed_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  source: text("source").default("general"),
});

// Table for crawler statistics
export const crawlerStats = pgTable("crawler_stats", {
  id: serial("id").primaryKey(),
  lastRunAt: timestamp("last_run_at").defaultNow(),
  pagesIndexed: integer("pages_indexed").default(0),
  queueSize: integer("queue_size").default(0),
});

// Types
export type CrawledPage = typeof crawledPages.$inferSelect;
export type InsertCrawledPage = typeof crawledPages.$inferInsert;

export type CrawlerStats = typeof crawlerStats.$inferSelect;
export type InsertCrawlerStats = typeof crawlerStats.$inferInsert;

// Insertion schemas
export const insertCrawledPageSchema = createInsertSchema(crawledPages);
export const insertCrawlerStatsSchema = createInsertSchema(crawlerStats);

// Search result type
export interface SearchResult {
  id: string;
  url: string;
  title: string;
  snippet: string;
  featured?: {
    title: string;
    description: string;
    image?: string;
    attributes?: Record<string, string | number>;
  };
}

// System Types
export interface IStorage {
  // Crawler methods
  addCrawledPage(page: InsertCrawledPage): Promise<CrawledPage>;
  getCrawledPage(id: string): Promise<CrawledPage | undefined>;
  updateCrawledPage(id: string, page: Partial<InsertCrawledPage>): Promise<CrawledPage | undefined>;
  deleteCrawledPage(id: string): Promise<boolean>;
  
  // Search methods
  searchCrawledPages(query: string, filters: any): Promise<CrawledPage[]>;
  
  // Stats methods
  updateCrawlerStats(stats: Partial<InsertCrawlerStats>): Promise<CrawlerStats>;
  getCrawlerStats(): Promise<CrawlerStats>;
  
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
}

// Users
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
