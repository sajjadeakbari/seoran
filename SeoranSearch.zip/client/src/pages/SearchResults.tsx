import { useState, useEffect } from "react";
import { useLocation, useSearch, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import FilterSidebar from "@/components/FilterSidebar";
import ResultsList from "@/components/ResultsList";
import Pagination from "@/components/Pagination";
import SearchBox from "@/components/SearchBox";
import { Search } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { SearchResult, SearchFilter } from "@/lib/searchTypes";

export default function SearchResults() {
  const [, setLocation] = useLocation();
  const search = useSearch();
  const searchParams = new URLSearchParams(search);
  const query = searchParams.get("q") || "";
  const page = parseInt(searchParams.get("page") || "1");
  
  const [searchQuery, setSearchQuery] = useState(query);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [filters, setFilters] = useState<SearchFilter>({
    time: "all",
    language: "fa",
    source: "all"
  });

  // Make sure query is in the URL when landing on this page
  useEffect(() => {
    if (!query) {
      setLocation("/");
    }
    setSearchQuery(query);
  }, [query, setLocation]);

  // Handle search form submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLocation(`/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  // Get search results
  const { data, isLoading, error } = useQuery<{
    results: SearchResult[],
    totalResults: number,
    queryTimeMs: number
  }>({
    queryKey: ['/api/search', query, page, filters],
    queryFn: () => apiRequest<{
      results: SearchResult[],
      totalResults: number,
      queryTimeMs: number
    }>(`/api/search?q=${encodeURIComponent(query)}&page=${page}&time=${filters.time}&language=${filters.language}&source=${filters.source}`),
    enabled: !!query
  });

  // Format number in Persian
  const formatNumberInPersian = (num: number) => {
    return new Intl.NumberFormat('fa-IR').format(num);
  };

  // Handle pagination
  const handlePageChange = (newPage: number) => {
    const params = new URLSearchParams(search);
    params.set("page", newPage.toString());
    setLocation(`/search?${params.toString()}`);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen">
      {/* Header with search */}
      <header className="py-3 px-4 sm:px-6 border-b border-gray-200 bg-white shadow-sm sticky top-0 z-10">
        <div className="container mx-auto">
          <div className="flex items-center">
            <Link href="/" className="md:ml-6 flex-shrink-0">
              <span className="logo-text text-2xl">Seoran</span>
            </Link>
            <div className="flex-1 md:max-w-xl mx-4">
              <SearchBox
                searchQuery={searchQuery}
                setSearchQuery={setSearchQuery}
                handleSearch={handleSearch}
              />
            </div>
          </div>
        </div>
      </header>
      
      {/* Main content */}
      <main className="container mx-auto px-4 sm:px-6 py-4">
        {/* Filters toggle for mobile */}
        <div className="flex items-center justify-between mb-4">
          <button 
            onClick={() => setFiltersOpen(!filtersOpen)}
            className="flex items-center space-x-reverse space-x-1 px-3 py-1.5 bg-gray-100 hover:bg-gray-200 rounded-md text-sm text-gray-700 md:hidden transition-colors"
          >
            <Search size={14} />
            <span>{filtersOpen ? 'پنهان کردن فیلترها' : 'نمایش فیلترها'}</span>
          </button>
          
          {data && (
            <div className="text-xs text-gray-500">
              حدود <span className="font-semibold">{formatNumberInPersian(data.totalResults)}</span> نتیجه 
              ({(data.queryTimeMs / 1000).toFixed(2)} ثانیه)
            </div>
          )}
        </div>
        
        {/* Content area with sidebar and results */}
        <div className="flex flex-col md:flex-row md:gap-6">
          <aside className={`md:block ${filtersOpen ? 'block' : 'hidden'} md:w-56 lg:w-64 flex-shrink-0 mb-6 md:mb-0`}>
            <div className="sticky top-20">
              <FilterSidebar filters={filters} setFilters={setFilters} query={query} />
            </div>
          </aside>
          
          <div className="flex-1">
            {isLoading ? (
              // Loading state
              <div className="space-y-6">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="h-3 bg-gray-200 rounded w-1/4 mb-2"></div>
                    <div className="h-5 bg-gray-200 rounded w-3/4 mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-full mb-1"></div>
                    <div className="h-4 bg-gray-200 rounded w-2/3"></div>
                  </div>
                ))}
              </div>
            ) : error ? (
              // Error state
              <div className="py-8 text-center bg-red-50 rounded-lg border border-red-100">
                <p className="text-red-500 font-medium">خطا در دریافت نتایج جستجو</p>
                <p className="text-gray-600 text-sm mt-2">لطفاً مجدداً تلاش کنید یا عبارت دیگری را جستجو نمایید.</p>
              </div>
            ) : data ? (
              // Results
              <>
                {/* Display results if available */}
                {data.results.length > 0 ? (
                  <>
                    <ResultsList results={data.results} query={query} />
                    
                    {/* Pagination */}
                    {data.totalResults > 10 && (
                      <div className="mt-8">
                        <Pagination 
                          currentPage={page} 
                          totalPages={Math.min(10, Math.ceil(data.totalResults / 10))}
                          onPageChange={handlePageChange}
                        />
                      </div>
                    )}
                  </>
                ) : (
                  <div className="py-12 text-center bg-gray-50 rounded-lg">
                    <p className="text-lg text-gray-800">نتیجه‌ای برای <span className="font-semibold">{query}</span> یافت نشد.</p>
                    <p className="text-gray-600 mt-3 mb-2">پیشنهادها:</p>
                    <ul className="text-sm text-gray-600 space-y-1 max-w-sm mx-auto">
                      <li>• املای کلمات خود را بررسی کنید</li>
                      <li>• از کلمات کلیدی دیگری استفاده کنید</li>
                      <li>• از کلمات کلیدی عمومی‌تر استفاده کنید</li>
                    </ul>
                  </div>
                )}
              </>
            ) : null}
          </div>
        </div>
      </main>
    </div>
  );
}
