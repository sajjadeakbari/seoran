import { useState } from "react";
import { useLocation } from "wouter";
import SearchBox from "@/components/SearchBox";

export default function Home() {
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLocation(`/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  return (
    <div className="min-h-[calc(100vh-120px)] flex flex-col items-center justify-center px-4">
      <div className="text-center mb-8">
        <h1 className="flex flex-col items-center justify-center">
          <span className="logo-text text-6xl tracking-tight">Seoran</span>
          <span className="text-sm text-neutral-500 mt-2 block">موتور جستجوی هوشمند فارسی</span>
        </h1>
      </div>
      
      <div className="w-full max-w-2xl mb-6">
        <SearchBox 
          searchQuery={searchQuery} 
          setSearchQuery={setSearchQuery} 
          handleSearch={handleSearch} 
          large={true}
        />
      </div>
      
      <div className="flex flex-wrap justify-center space-x-reverse space-x-3 mb-6">
        <button 
          className="bg-gray-50 hover:bg-gray-100 py-2 px-4 text-sm text-gray-700 rounded border border-transparent transition-colors mb-2"
          onClick={(e) => {
            setSearchQuery("سئو و بهینه سازی");
            handleSearch(e as unknown as React.FormEvent);
          }}
        >
          سئو و بهینه‌سازی
        </button>
        <button 
          className="bg-gray-50 hover:bg-gray-100 py-2 px-4 text-sm text-gray-700 rounded border border-transparent transition-colors mb-2"
          onClick={(e) => {
            setSearchQuery("دیجیتال مارکتینگ");
            handleSearch(e as unknown as React.FormEvent);
          }}
        >
          دیجیتال مارکتینگ
        </button>
        <button 
          className="bg-gray-50 hover:bg-gray-100 py-2 px-4 text-sm text-gray-700 rounded border border-transparent transition-colors mb-2"
          onClick={(e) => {
            setSearchQuery("مهندسی نرم‌افزار");
            handleSearch(e as unknown as React.FormEvent);
          }}
        >
          مهندسی نرم‌افزار
        </button>
      </div>
    </div>
  );
}
