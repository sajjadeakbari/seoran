import { Card, CardContent } from "@/components/ui/card";

export default function About() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <Card className="mb-6">
          <CardContent className="p-6">
            <h1 className="text-2xl font-bold mb-4">درباره Seoran</h1>
            <p className="text-neutral-600 mb-4">
              Seoran یک موتور جستجوی تخصصی برای زبان فارسی است که با هدف بهبود دسترسی به محتوای فارسی وب طراحی و پیاده‌سازی شده است.
              این موتور جستجو با استفاده از الگوریتم‌های پیشرفته، صفحات وب فارسی را جمع‌آوری، ایندکس و بر اساس جستجوی کاربران، مرتب و نمایش می‌دهد.
            </p>
            
            <h2 className="text-xl font-bold mt-6 mb-3">ویژگی‌های سیوران</h2>
            <ul className="list-disc mr-6 space-y-2 text-neutral-600">
              <li>جستجوی اختصاصی محتوای فارسی</li>
              <li>پشتیبانی کامل از متون فارسی و استانداردهای نگارش فارسی</li>
              <li>الگوریتم رتبه‌بندی هوشمند برای نتایج بهتر</li>
              <li>خزش و ایندکس‌گذاری منظم محتوای وب فارسی</li>
              <li>رابط کاربری ساده و کاربرپسند</li>
              <li>فیلترهای پیشرفته برای محدود کردن نتایج جستجو</li>
            </ul>
            
            <h2 className="text-xl font-bold mt-6 mb-3">چشم‌انداز ما</h2>
            <p className="text-neutral-600 mb-4">
              هدف ما در سیوران، ارائه دسترسی آسان، سریع و دقیق به محتوای فارسی وب است. ما معتقدیم که کاربران فارسی‌زبان باید بتوانند به راحتی به اطلاعات مورد نیاز خود دسترسی داشته باشند، بدون اینکه با محدودیت‌های زبانی مواجه شوند.
            </p>
            
            <h2 className="text-xl font-bold mt-6 mb-3">توسعه‌دهنده</h2>
            <p className="text-neutral-600">
              سیوران توسط{" "}
              <a 
                href="https://sajjadakbari.ir" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-primary hover:underline"
              >
                سجاد اکبری
              </a>{" "}
              طراحی و توسعه داده شده است. برای اطلاعات بیشتر در مورد پروژه‌ها و فعالیت‌های دیگر، می‌توانید به وب‌سایت شخصی ایشان مراجعه کنید.
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <h2 className="text-xl font-bold mb-4">تماس با ما</h2>
            <p className="text-neutral-600 mb-6">
              برای پیشنهادات، انتقادات یا همکاری، می‌توانید از طریق روش‌های زیر با ما در ارتباط باشید:
            </p>
            
            <div className="space-y-3">
              <div className="flex items-center">
                <span className="ml-2 text-primary">ایمیل:</span>
                <a href="mailto:info@seoran.ir" className="text-neutral-600 hover:text-primary">info@seoran.ir</a>
              </div>
              <div className="flex items-center">
                <span className="ml-2 text-primary">وب‌سایت:</span>
                <a href="https://sajjadakbari.ir" target="_blank" rel="noopener noreferrer" className="text-neutral-600 hover:text-primary">sajjadakbari.ir</a>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
