import { Link } from 'wouter';

export default function Footer() {
  return (
    <footer className="bg-white border-t border-neutral-200 py-3">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex space-x-reverse space-x-4 mb-2 md:mb-0">
            <Link href="/about" className="text-xs text-neutral-600 hover:text-primary">درباره ما</Link>
            <a href="#" className="text-xs text-neutral-600 hover:text-primary">حریم خصوصی</a>
            <a href="#" className="text-xs text-neutral-600 hover:text-primary">شرایط استفاده</a>
          </div>
          
          <div className="text-xs text-neutral-600">
            <span>© ۱۴۰۴ Seoran - توسعه داده شده توسط </span>
            <a 
              href="https://sajjadakbari.ir" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="text-primary hover:underline"
            >
              سجاد اکبری
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
