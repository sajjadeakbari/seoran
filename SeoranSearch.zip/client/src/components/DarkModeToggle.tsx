import { useTheme } from "@/lib/ThemeProvider";

export default function DarkModeToggle() {
  const { theme, setTheme } = useTheme();
  
  return (
    <button 
      type="button" 
      className="p-2 text-neutral-600 hover:text-primary transition"
      onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
      aria-label={theme === 'dark' ? 'روشن کردن تم' : 'تاریک کردن تم'}
    >
      {theme === 'dark' ? (
        <i className="fas fa-sun"></i>
      ) : (
        <i className="fas fa-moon"></i>
      )}
    </button>
  );
}
