import { useLocation } from "wouter";
import { SearchResult } from "@/lib/searchTypes";

interface ResultsListProps {
  results: SearchResult[];
  query: string;
}

export default function ResultsList({ results, query }: ResultsListProps) {
  const [, setLocation] = useLocation();
  
  if (!results.length) {
    return (
      <div className="text-center py-12">
        <h2 className="text-xl text-neutral-800 mb-2">متأسفانه نتیجه‌ای یافت نشد</h2>
        <p className="text-neutral-600">
          لطفاً عبارت جستجوی خود را تغییر دهید یا فیلترهای دیگری را امتحان کنید.
        </p>
      </div>
    );
  }
  
  // Check if the first result has a featured snippet (info card)
  const hasFeaturedSnippet = results.length > 0 && results[0].featured;
  
  // Display a URL in a readable format
  const formatUrl = (url: string) => {
    try {
      const { hostname, pathname } = new URL(url);
      return `${hostname}${pathname.length > 1 ? pathname : ''}`;
    } catch (e) {
      return url;
    }
  };
  
  return (
    <div className="space-y-6">
      {/* Featured Snippet / Quick Information Card */}
      {hasFeaturedSnippet && results[0].featured && (
        <div className="border border-gray-200 rounded-lg p-4 bg-white shadow-sm hover:shadow-md transition-shadow">
          <div className="flex flex-col md:flex-row">
            {results[0].featured.image && (
              <div className="md:w-1/3 md:ml-4 mb-4 md:mb-0 flex items-center justify-center">
                <img 
                  src={results[0].featured.image} 
                  alt={results[0].featured.title || query} 
                  className="w-full max-w-xs h-auto rounded"
                  loading="lazy"
                />
              </div>
            )}
            <div className={results[0].featured.image ? "md:w-2/3" : "w-full"}>
              <h2 className="text-lg font-bold mb-2">{results[0].featured.title}</h2>
              <p className="text-gray-600 text-sm mb-3">{results[0].featured.description}</p>
              
              {results[0].featured.attributes && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                  {Object.entries(results[0].featured.attributes).map(([key, value], index) => (
                    <div key={index} className="flex">
                      <span className="text-xs font-medium text-gray-700 ml-1">{key}:</span>
                      {typeof value === 'string' && value.startsWith('http') ? (
                        <a href={value} className="text-primary hover:underline text-xs" target="_blank" rel="noopener noreferrer">
                          {value.replace(/^https?:\/\//, '')}
                        </a>
                      ) : (
                        <span className="text-xs text-gray-600">{value}</span>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
          <div className="mt-3 text-left">
            <a 
              href={results[0].url} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="text-xs text-primary hover:underline inline-flex items-center"
            >
              مشاهده منبع
              <span className="ml-1">›</span>
            </a>
          </div>
        </div>
      )}
      
      {/* Regular Search Results */}
      {results.map((result, index) => (
        <div 
          key={result.id} 
          className="result-item p-3 rounded-lg hover:bg-gray-50 transition-colors" 
          style={{ animationDelay: `${0.05 + (index * 0.03)}s` }}
        >
          <a href={result.url} target="_blank" rel="noopener noreferrer" className="block">
            <div className="result-link">{formatUrl(result.url)}</div>
            <h3 className="result-title">{result.title}</h3>
            <p className="result-snippet">{result.snippet}</p>
          </a>
        </div>
      ))}
    </div>
  );
}
