import { useState } from "react";
import { Search, X, Mic } from "lucide-react";

interface SearchBoxProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  handleSearch: (e: React.FormEvent) => void;
  large?: boolean;
}

export default function SearchBox({ 
  searchQuery, 
  setSearchQuery, 
  handleSearch,
  large = false
}: SearchBoxProps) {
  const [isVoiceSearchActive, setIsVoiceSearchActive] = useState(false);
  
  const handleClearSearch = () => {
    setSearchQuery("");
  };
  
  const handleVoiceSearch = () => {
    if ('webkitSpeechRecognition' in window) {
      setIsVoiceSearchActive(true);
      
      try {
        // @ts-ignore - Web Speech API is not fully typed in TypeScript
        const recognition = new window.webkitSpeechRecognition();
        recognition.lang = 'fa-IR';
        recognition.continuous = false;
        recognition.interimResults = false;
        
        recognition.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          setSearchQuery(transcript);
          setIsVoiceSearchActive(false);
        };
        
        recognition.onerror = () => {
          setIsVoiceSearchActive(false);
        };
        
        recognition.onend = () => {
          setIsVoiceSearchActive(false);
        };
        
        recognition.start();
      } catch (e) {
        setIsVoiceSearchActive(false);
        console.error("Speech recognition error", e);
      }
    } else {
      alert("متأسفانه مرورگر شما از تشخیص گفتار پشتیبانی نمی‌کند.");
    }
  };
  
  const boxWidth = large ? 'max-w-xl mx-auto w-full' : 'w-full';
  const boxScale = large ? 'md:scale-105' : '';
  const inputHeight = large ? 'h-12' : 'h-10'; 
  const iconSize = large ? 18 : 16;
  
  return (
    <div className={`${boxWidth} ${boxScale}`}>
      <form className="relative flex w-full" onSubmit={handleSearch}>
        <input 
          type="text" 
          placeholder="جستجو در وب فارسی..." 
          className={`w-full ${inputHeight} px-4 pr-5 border border-gray-200 hover:border-gray-300 focus:border-primary/60 rounded-full shadow-sm hover:shadow focus:shadow-md focus:outline-none transition-all text-right`}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        
        <div className="absolute inset-y-0 left-0 flex items-center">
          {searchQuery && (
            <button 
              type="button" 
              className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
              onClick={handleClearSearch}
              aria-label="پاک کردن متن جستجو"
            >
              <X size={iconSize} />
            </button>
          )}
          
          <button 
            type="button" 
            className={`p-2 transition-colors ${isVoiceSearchActive ? 'text-primary animate-pulse' : 'text-gray-400 hover:text-gray-600'}`}
            onClick={handleVoiceSearch}
            aria-label="جستجوی صوتی"
          >
            <Mic size={iconSize} />
          </button>
          
          <button 
            type="submit" 
            className="p-3 ml-1 mr-1 bg-primary text-white hover:bg-primary/90 rounded-full transition-colors"
            aria-label="جستجو"
          >
            <Search size={iconSize-1} />
          </button>
        </div>
      </form>
    </div>
  );
}
