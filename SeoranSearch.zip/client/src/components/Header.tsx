import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Link } from 'wouter';
import SearchBox from './SearchBox';
import DarkModeToggle from './DarkModeToggle';

export default function Header() {
  const [location, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [isScrolled, setIsScrolled] = useState(false);
  
  // Get query from URL if on search page
  useEffect(() => {
    if (location.startsWith('/search')) {
      const params = new URLSearchParams(location.split('?')[1]);
      const q = params.get('q');
      if (q) setSearchQuery(q);
    }
  }, [location]);
  
  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLocation(`/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };
  
  const isSearchPage = location.startsWith('/search');
  const isHomePage = location === '/';
  
  // Simple header for homepage
  if (isHomePage) {
    return (
      <header className="py-2">
        <div className="container mx-auto px-4">
          <div className="flex justify-end">
            <nav className="flex items-center gap-2">
              <Link href="/about" className="px-2 py-1 text-sm text-neutral-600 hover:text-primary transition">درباره ما</Link>
              <DarkModeToggle />
            </nav>
          </div>
        </div>
      </header>
    );
  }
  
  // Full header for search results and other pages
  return (
    <header className={`sticky top-0 bg-white z-10 transition-shadow ${isScrolled ? 'shadow-sm' : ''}`}>
      <div className="container mx-auto px-4 py-2">
        <div className="flex items-center justify-between">
          {/* Logo and Search Area */}
          <div className="flex items-center flex-grow">
            <Link href="/" className="flex items-center ml-4">
              <span className="text-primary text-xl font-bold">Seoran</span>
              <span className="text-secondary text-xs font-light mr-1">beta</span>
            </Link>
            
            {/* Search input */}
            <div className="flex-grow max-w-2xl">
              <SearchBox 
                searchQuery={searchQuery} 
                setSearchQuery={setSearchQuery} 
                handleSearch={handleSearch} 
                large={false}
              />
            </div>
          </div>
          
          {/* Navigation */}
          <nav className="hidden md:flex items-center">
            <DarkModeToggle />
            <Link href="/about" className="ml-2 text-sm text-neutral-600 hover:text-primary transition">درباره ما</Link>
          </nav>
        </div>
        
        {/* Search Type Tabs - only show on search page */}
        {isSearchPage && (
          <div className="mt-2 border-b border-neutral-200">
            <div className="flex space-x-reverse space-x-6 overflow-x-auto pb-1 scrollbar-hide">
              <a href="#" className="px-2 py-2 text-sm text-primary border-b-2 border-primary whitespace-nowrap">همه</a>
              <a href="#" className="px-2 py-2 text-sm text-neutral-600 hover:text-primary whitespace-nowrap">تصاویر</a>
              <a href="#" className="px-2 py-2 text-sm text-neutral-600 hover:text-primary whitespace-nowrap">اخبار</a>
              <a href="#" className="px-2 py-2 text-sm text-neutral-600 hover:text-primary whitespace-nowrap">ویدیو</a>
              <a href="#" className="px-2 py-2 text-sm text-neutral-600 hover:text-primary whitespace-nowrap">نقشه</a>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
