import { Link } from "wouter";
import { SearchFilter } from "@/lib/searchTypes";
import { Clock, Globe, Newspaper } from "lucide-react";

interface FilterSidebarProps {
  filters: SearchFilter;
  setFilters: (filters: SearchFilter) => void;
  query: string;
}

export default function FilterSidebar({ filters, setFilters, query }: FilterSidebarProps) {
  const handleTimeFilter = (time: string) => {
    setFilters({ ...filters, time });
  };
  
  const handleLanguageFilter = (language: string) => {
    setFilters({ ...filters, language });
  };
  
  const handleSourceFilter = (source: string) => {
    setFilters({ ...filters, source });
  };
  
  // Generate related searches based on the current query
  const getRelatedSearches = (query: string) => {
    if (!query) return [];
    
    // In a real app, these would come from the API
    const relatedQueries = [
      `${query} آموزش`,
      `${query} چیست`,
      `${query} در ایران`,
      `بهترین ${query}`,
      `مقالات ${query}`
    ];
    
    return relatedQueries;
  };
  
  const relatedSearches = getRelatedSearches(query);
  
  const FilterButton = ({ 
    active, 
    onClick, 
    children 
  }: { 
    active: boolean; 
    onClick: () => void; 
    children: React.ReactNode 
  }) => (
    <button 
      onClick={onClick}
      className={`text-sm py-1.5 w-full text-right transition-colors ${
        active 
          ? "text-primary font-medium" 
          : "text-gray-600 hover:text-primary hover:bg-gray-50"
      }`}
    >
      {children}
    </button>
  );
  
  return (
    <div className="space-y-4">
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="p-3 border-b border-gray-200 bg-gray-50">
          <h3 className="font-semibold text-gray-800 flex items-center">
            <Clock size={16} className="ml-1.5" />
            زمان
          </h3>
        </div>
        <div className="p-2">
          <ul className="space-y-0.5">
            <li>
              <FilterButton 
                active={filters.time === "all"}
                onClick={() => handleTimeFilter("all")}
              >
                همه زمان‌ها
              </FilterButton>
            </li>
            <li>
              <FilterButton 
                active={filters.time === "24h"}
                onClick={() => handleTimeFilter("24h")}
              >
                24 ساعت گذشته
              </FilterButton>
            </li>
            <li>
              <FilterButton 
                active={filters.time === "week"}
                onClick={() => handleTimeFilter("week")}
              >
                هفته گذشته
              </FilterButton>
            </li>
            <li>
              <FilterButton 
                active={filters.time === "month"}
                onClick={() => handleTimeFilter("month")}
              >
                ماه گذشته
              </FilterButton>
            </li>
            <li>
              <FilterButton 
                active={filters.time === "year"}
                onClick={() => handleTimeFilter("year")}
              >
                سال گذشته
              </FilterButton>
            </li>
          </ul>
        </div>
      </div>
      
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="p-3 border-b border-gray-200 bg-gray-50">
          <h3 className="font-semibold text-gray-800 flex items-center">
            <Globe size={16} className="ml-1.5" />
            زبان
          </h3>
        </div>
        <div className="p-2">
          <ul className="space-y-0.5">
            <li>
              <FilterButton 
                active={filters.language === "fa"}
                onClick={() => handleLanguageFilter("fa")}
              >
                فارسی
              </FilterButton>
            </li>
            <li>
              <FilterButton 
                active={filters.language === "en"}
                onClick={() => handleLanguageFilter("en")}
              >
                انگلیسی
              </FilterButton>
            </li>
            <li>
              <FilterButton 
                active={filters.language === "ar"}
                onClick={() => handleLanguageFilter("ar")}
              >
                عربی
              </FilterButton>
            </li>
            <li>
              <FilterButton 
                active={filters.language === "all"}
                onClick={() => handleLanguageFilter("all")}
              >
                همه زبان‌ها
              </FilterButton>
            </li>
          </ul>
        </div>
      </div>
      
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="p-3 border-b border-gray-200 bg-gray-50">
          <h3 className="font-semibold text-gray-800 flex items-center">
            <Newspaper size={16} className="ml-1.5" />
            منابع
          </h3>
        </div>
        <div className="p-2">
          <ul className="space-y-0.5">
            <li>
              <FilterButton 
                active={filters.source === "all"}
                onClick={() => handleSourceFilter("all")}
              >
                همه منابع
              </FilterButton>
            </li>
            <li>
              <FilterButton 
                active={filters.source === "academic"}
                onClick={() => handleSourceFilter("academic")}
              >
                سایت‌های دانشگاهی
              </FilterButton>
            </li>
            <li>
              <FilterButton 
                active={filters.source === "news"}
                onClick={() => handleSourceFilter("news")}
              >
                سایت‌های خبری
              </FilterButton>
            </li>
            <li>
              <FilterButton 
                active={filters.source === "blogs"}
                onClick={() => handleSourceFilter("blogs")}
              >
                وبلاگ‌ها
              </FilterButton>
            </li>
            <li>
              <FilterButton 
                active={filters.source === "scientific"}
                onClick={() => handleSourceFilter("scientific")}
              >
                مقالات علمی
              </FilterButton>
            </li>
          </ul>
        </div>
      </div>
      
      {relatedSearches.length > 0 && (
        <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
          <div className="p-3 border-b border-gray-200 bg-gray-50">
            <h3 className="font-semibold text-gray-800 flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-1.5">
                <circle cx="11" cy="11" r="8"></circle>
                <path d="m21 21-4.3-4.3"></path>
                <path d="M11 8v6"></path>
                <path d="M8 11h6"></path>
              </svg>
              جستجوهای مرتبط
            </h3>
          </div>
          <div className="p-2">
            <ul className="space-y-0.5">
              {relatedSearches.map((search, index) => (
                <li key={index}>
                  <Link 
                    href={`/search?q=${encodeURIComponent(search)}`} 
                    className="text-sm text-gray-600 hover:text-primary hover:bg-gray-50 block py-1.5 px-2 rounded transition-colors"
                  >
                    {search}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}
