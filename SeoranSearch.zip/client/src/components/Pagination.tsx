interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

export default function Pagination({ currentPage, totalPages, onPageChange }: PaginationProps) {
  // Convert number to Persian digits
  const toPersianDigits = (num: number) => {
    const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return num.toString().replace(/\d/g, (digit) => persianDigits[parseInt(digit)]);
  };
  
  // Function to generate page numbers array
  const getPageNumbers = () => {
    const pageNumbers = [];
    const maxPagesToShow = 5;
    
    if (totalPages <= maxPagesToShow) {
      // Show all pages if total pages are less than max pages to show
      for (let i = 1; i <= totalPages; i++) {
        pageNumbers.push(i);
      }
    } else {
      // Calculate start and end page numbers
      let startPage = Math.max(1, currentPage - Math.floor(maxPagesToShow / 2));
      let endPage = startPage + maxPagesToShow - 1;
      
      if (endPage > totalPages) {
        endPage = totalPages;
        startPage = Math.max(1, endPage - maxPagesToShow + 1);
      }
      
      for (let i = startPage; i <= endPage; i++) {
        pageNumbers.push(i);
      }
    }
    
    return pageNumbers;
  };
  
  const pageNumbers = getPageNumbers();
  
  return (
    <div className="mt-6 flex justify-center">
      <nav className="inline-flex rounded-md shadow">
        {/* Previous Page Button */}
        <button
          onClick={() => currentPage > 1 && onPageChange(currentPage - 1)}
          disabled={currentPage === 1}
          className={`px-3 py-2 rounded-r-md bg-white border border-neutral-200 ${
            currentPage === 1 
              ? 'text-neutral-400 cursor-not-allowed' 
              : 'text-neutral-600 hover:bg-neutral-100 transition'
          }`}
        >
          <i className="fas fa-chevron-right"></i>
        </button>
        
        {/* Page Numbers */}
        {pageNumbers.map(number => (
          <button
            key={number}
            onClick={() => onPageChange(number)}
            className={`px-4 py-2 border ${
              currentPage === number
                ? 'bg-primary text-white border-primary'
                : 'bg-white border-neutral-200 text-neutral-600 hover:bg-neutral-100 transition'
            }`}
          >
            {toPersianDigits(number)}
          </button>
        ))}
        
        {/* Next Page Button */}
        <button
          onClick={() => currentPage < totalPages && onPageChange(currentPage + 1)}
          disabled={currentPage === totalPages}
          className={`px-3 py-2 rounded-l-md bg-white border border-neutral-200 ${
            currentPage === totalPages 
              ? 'text-neutral-400 cursor-not-allowed' 
              : 'text-neutral-600 hover:bg-neutral-100 transition'
          }`}
        >
          <i className="fas fa-chevron-left"></i>
        </button>
      </nav>
    </div>
  );
}
