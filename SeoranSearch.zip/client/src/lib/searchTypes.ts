export interface SearchResult {
  id: string;
  url: string;
  title: string;
  snippet: string;
  featured?: {
    title: string;
    description: string;
    image?: string;
    attributes?: Record<string, string | number>;
  };
}

export interface SearchFilter {
  time: string;
  language: string;
  source: string;
}

export interface CrawledPage {
  id: string;
  url: string;
  title: string;
  content: string;
  description: string;
  language: string;
  indexedAt: Date;
  updatedAt: Date;
  source: string;
}
