import { CrawledPage } from "@/lib/searchTypes";

// Simple in-memory inverted index
export class InvertedIndex {
  private index: Map<string, Set<string>> = new Map();
  private documents: Map<string, CrawledPage> = new Map();
  
  // Add a document to the index
  public addDocument(page: CrawledPage): void {
    // Store the document
    this.documents.set(page.id, page);
    
    // Extract terms from the document
    const terms = this.extractTerms(page.title + ' ' + page.content + ' ' + page.description);
    
    // Add document ID to the posting list for each term
    terms.forEach(term => {
      if (!this.index.has(term)) {
        this.index.set(term, new Set());
      }
      this.index.get(term)?.add(page.id);
    });
  }
  
  // Remove a document from the index
  public removeDocument(pageId: string): void {
    // Remove document from documents map
    this.documents.delete(pageId);
    
    // Remove document ID from all posting lists
    this.index.forEach((postingList) => {
      postingList.delete(pageId);
    });
    
    // Clean up empty posting lists
    this.index.forEach((postingList, term) => {
      if (postingList.size === 0) {
        this.index.delete(term);
      }
    });
  }
  
  // Extract terms from text (tokenization)
  private extractTerms(text: string): string[] {
    // Split text into tokens
    const tokens = text
      .toLowerCase()
      .replace(/[.,:;()\[\]{}'"!?-]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .split(' ');
    
    // Remove duplicates
    return [...new Set(tokens)];
  }
  
  // Search the index for a query
  public search(query: string, filters: any): { pages: CrawledPage[], total: number } {
    // Extract query terms
    const queryTerms = this.extractTerms(query);
    
    // Find document IDs that match all query terms
    const matchingDocIds = new Set<string>();
    let isFirstTerm = true;
    
    queryTerms.forEach(term => {
      const postingList = this.index.get(term);
      
      if (postingList) {
        if (isFirstTerm) {
          // Initialize with the first term's posting list
          postingList.forEach(docId => matchingDocIds.add(docId));
          isFirstTerm = false;
        } else {
          // Intersect with subsequent terms' posting lists
          const intersection = new Set<string>();
          matchingDocIds.forEach(docId => {
            if (postingList.has(docId)) {
              intersection.add(docId);
            }
          });
          // Update matchingDocIds to only include the intersection
          matchingDocIds.clear();
          intersection.forEach(docId => matchingDocIds.add(docId));
        }
      }
    });
    
    // Retrieve matching documents
    const matchingDocs = Array.from(matchingDocIds)
      .map(docId => this.documents.get(docId))
      .filter(doc => doc !== undefined) as CrawledPage[];
    
    // Apply filters
    const filteredDocs = this.applyFilters(matchingDocs, filters);
    
    // Rank documents
    const rankedDocs = this.rankDocuments(filteredDocs, query);
    
    return {
      pages: rankedDocs,
      total: filteredDocs.length
    };
  }
  
  // Apply filters to the search results
  private applyFilters(docs: CrawledPage[], filters: any): CrawledPage[] {
    return docs.filter(doc => {
      // Language filter
      if (filters.language !== 'all' && doc.language !== filters.language) {
        return false;
      }
      
      // Source filter
      if (filters.source !== 'all' && doc.source !== filters.source) {
        return false;
      }
      
      // Time filter
      if (filters.time !== 'all') {
        const now = new Date();
        const docDate = new Date(doc.indexedAt);
        const diffInDays = (now.getTime() - docDate.getTime()) / (1000 * 60 * 60 * 24);
        
        switch (filters.time) {
          case '24h':
            if (diffInDays > 1) return false;
            break;
          case 'week':
            if (diffInDays > 7) return false;
            break;
          case 'month':
            if (diffInDays > 30) return false;
            break;
          case 'year':
            if (diffInDays > 365) return false;
            break;
        }
      }
      
      return true;
    });
  }
  
  // Simple TF-IDF based ranking algorithm
  private rankDocuments(docs: CrawledPage[], query: string): CrawledPage[] {
    const queryTerms = this.extractTerms(query);
    const scores = new Map<string, number>();
    
    docs.forEach(doc => {
      let score = 0;
      
      // Calculate TF-IDF for each query term
      queryTerms.forEach(term => {
        // Term frequency in document
        const tf = (doc.title + ' ' + doc.content).toLowerCase().split(term).length - 1;
        
        // Inverse document frequency
        const idf = Math.log(this.documents.size / (this.index.get(term)?.size || 1));
        
        // Boost score if term appears in title
        const titleBoost = doc.title.toLowerCase().includes(term) ? 2.0 : 1.0;
        
        // Boost score if term appears in URL
        const urlBoost = doc.url.toLowerCase().includes(term) ? 1.5 : 1.0;
        
        // Add to score
        score += tf * idf * titleBoost * urlBoost;
      });
      
      scores.set(doc.id, score);
    });
    
    // Sort documents by score
    return docs.sort((a, b) => {
      const scoreA = scores.get(a.id) || 0;
      const scoreB = scores.get(b.id) || 0;
      return scoreB - scoreA;
    });
  }
  
  // Get the number of documents in the index
  public getDocumentCount(): number {
    return this.documents.size;
  }
  
  // Get the number of terms in the index
  public getTermCount(): number {
    return this.index.size;
  }
}

// Singleton instance of the inverted index
export const indexInstance = new InvertedIndex();
