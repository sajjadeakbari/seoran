import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { startCrawler, scheduleCrawling } from "./crawler";
import { searchPages } from "./searcher";
import { v4 as uuidv4 } from 'uuid';

// Demo search results for testing
const demoSearchResults = [
  {
    id: "demo-1",
    url: "https://example.com/seo-guide",
    title: "راهنمای جامع سئو و بهینه‌سازی موتورهای جستجو",
    snippet: "در این مقاله با تکنیک‌های مدرن سئو آشنا می‌شوید. از بهینه‌سازی محتوا گرفته تا استراتژی‌های لینک‌سازی و روش‌های افزایش رتبه در نتایج جستجو. تمام نکات کاربردی برای طراحان و توسعه‌دهندگان وب.",
    language: "fa",
    source: "blogs"
  },
  {
    id: "demo-2",
    url: "https://demo.ir/digital-marketing",
    title: "دیجیتال مارکتینگ و تأثیر آن بر کسب و کارهای آنلاین",
    snippet: "بررسی روش‌های مؤثر بازاریابی دیجیتال برای کسب و کارهای ایرانی. استراتژی‌های اثربخش در شبکه‌های اجتماعی، ایمیل مارکتینگ و تبلیغات آنلاین که باعث رشد فروش و افزایش مشتریان می‌شود.",
    language: "fa",
    source: "academic"
  },
  {
    id: "demo-3",
    url: "https://fa.wikipedia.org/wiki/مهندسی_نرم‌افزار",
    title: "مهندسی نرم‌افزار - ویکی‌پدیا",
    snippet: "مهندسی نرم‌افزار شاخه‌ای از مهندسی است که به طراحی و ساخت نرم‌افزار با استفاده از اصول مهندسی می‌پردازد. مهندسان نرم‌افزار نرم‌افزارهای کامپیوتری را تحلیل، طراحی، ارزیابی و آزمایش می‌کنند.",
    featured: {
      title: "مهندسی نرم‌افزار",
      description: "شاخه‌ای از مهندسی که به طراحی و ساخت نرم‌افزار با استفاده از اصول مهندسی می‌پردازد. این دانش شامل روش‌های مختلف توسعه نرم‌افزار، مدیریت پروژه و الگوهای طراحی است.",
      attributes: {
        "تعریف": "طراحی و ساخت نرم‌افزار با اصول مهندسی",
        "زمینه": "علوم کامپیوتر",
        "کاربرد": "توسعه سیستم‌های نرم‌افزاری",
        "روش‌ها": "آبشاری، اسکرام، چابک"
      }
    },
    language: "fa",
    source: "general"
  }
];

// Add seed data to database
async function addDemoDataIfNeeded() {
  try {
    // Check if we already have some pages
    const demoPage = await storage.getCrawledPage("demo-1");
    
    if (!demoPage) {
      console.log("Adding demo search results to database...");
      
      // Add demo search results
      for (const result of demoSearchResults) {
        await storage.addCrawledPage({
          id: result.id,
          url: result.url,
          title: result.title,
          content: result.snippet,
          description: result.snippet.substring(0, 160),
          language: result.language || "fa",
          indexedAt: new Date(),
          updatedAt: new Date(),
          source: result.source || "general"
        });
      }
      
      console.log("Demo data added successfully");
    }
  } catch (error) {
    console.error("Error adding demo data:", error);
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Start the web crawler
  startCrawler();
  
  // Schedule periodic crawling
  scheduleCrawling();
  
  // Add some demo data
  await addDemoDataIfNeeded();
  
  // API routes
  app.get('/api/search', async (req, res) => {
    try {
      const query = req.query.q as string || "";
      const page = parseInt(req.query.page as string) || 1;
      const filters = {
        time: (req.query.time as string) || "all",
        language: (req.query.language as string) || "fa",
        source: (req.query.source as string) || "all"
      };
      
      if (!query.trim()) {
        return res.status(400).json({ 
          message: "جستجو نمی‌تواند خالی باشد" 
        });
      }
      
      const startTime = Date.now();
      const results = await searchPages(query, page, filters);
      const queryTimeMs = Date.now() - startTime;
      
      res.json({
        results: results.pages,
        totalResults: results.total || demoSearchResults.length,
        queryTimeMs
      });
    } catch (error) {
      console.error("Search error:", error);
      res.status(500).json({ 
        message: "خطا در جستجو. لطفاً دوباره تلاش کنید." 
      });
    }
  });
  
  // API to get crawling status
  app.get('/api/status', async (req, res) => {
    try {
      const stats = await storage.getCrawlerStats();
      res.json(stats);
    } catch (error) {
      console.error("Status error:", error);
      res.status(500).json({ 
        message: "خطا در دریافت وضعیت. لطفاً دوباره تلاش کنید." 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
