import { storage } from './storage';
import { indexInstance } from './indexer';
import { SearchResult, CrawledPage } from '@/lib/searchTypes';

// Number of results per page
const RESULTS_PER_PAGE = 10;

// Search pages based on query and filters
export async function searchPages(query: string, page: number, filters: any): Promise<{ pages: SearchResult[], total: number }> {
  // Normalize page number
  const pageNum = Math.max(1, page);
  const offset = (pageNum - 1) * RESULTS_PER_PAGE;
  
  // Get results from index
  const results = indexInstance.search(query, filters);
  
  // If we don't have any results yet or only a few, try to get some from the database
  if (results.pages.length < 20) {
    try {
      const dbPages = await storage.searchCrawledPages(query, filters);
      
      // Add these to the index
      dbPages.forEach(page => {
        indexInstance.addDocument(page);
      });
      
      // Search again with the updated index
      const updatedResults = indexInstance.search(query, filters);
      
      // Paginate results
      const paginatedResults = updatedResults.pages.slice(offset, offset + RESULTS_PER_PAGE);
      
      // Convert to search results
      const searchResults = paginatedResults.map(pageToSearchResult);
      
      // Add a featured snippet for the first result if appropriate
      if (pageNum === 1 && searchResults.length > 0) {
        searchResults[0] = addFeaturedSnippet(searchResults[0], query);
      }
      
      return {
        pages: searchResults,
        total: updatedResults.total
      };
    } catch (error) {
      console.error('Error searching pages from DB:', error);
      
      // Still return whatever we have from the index
      const paginatedResults = results.pages.slice(offset, offset + RESULTS_PER_PAGE);
      
      return {
        pages: paginatedResults.map(pageToSearchResult),
        total: results.total
      };
    }
  }
  
  // Paginate results
  const paginatedResults = results.pages.slice(offset, offset + RESULTS_PER_PAGE);
  
  // Convert to search results
  const searchResults = paginatedResults.map(pageToSearchResult);
  
  // Add a featured snippet for the first result if appropriate
  if (pageNum === 1 && searchResults.length > 0) {
    searchResults[0] = addFeaturedSnippet(searchResults[0], query);
  }
  
  return {
    pages: searchResults,
    total: results.total
  };
}

// Convert a crawled page to a search result
function pageToSearchResult(page: CrawledPage): SearchResult {
  // Generate a snippet from the content
  const snippet = generateSnippet(page.content, 200);
  
  return {
    id: page.id,
    url: page.url,
    title: page.title || new URL(page.url).hostname,
    snippet: snippet || page.description || 'بدون توضیحات'
  };
}

// Generate a snippet from the content
function generateSnippet(content: string, maxLength: number): string {
  if (!content) return '';
  
  // Remove extra whitespace
  const cleanContent = content.replace(/\s+/g, ' ').trim();
  
  // If content is shorter than max length, return it all
  if (cleanContent.length <= maxLength) {
    return cleanContent;
  }
  
  // Otherwise, truncate and add ellipsis
  return cleanContent.substring(0, maxLength - 3) + '...';
}

// Add featured snippet to a search result if appropriate
function addFeaturedSnippet(result: SearchResult, query: string): SearchResult {
  // Only add featured snippets for certain domains or content types
  // This is a simple implementation - in a real app, this would be more sophisticated
  const url = new URL(result.url);
  const hostname = url.hostname;
  
  // For Wikipedia pages
  if (hostname.includes('wikipedia')) {
    return {
      ...result,
      featured: {
        title: result.title,
        description: result.snippet,
        image: 'https://images.unsplash.com/photo-1576495199011-eb94736d05d6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400',
        attributes: {
          'نوع': 'دانشنامه',
          'منبع': 'ویکی‌پدیا',
          'زبان': 'فارسی',
          'پیوند': result.url
        }
      }
    };
  }
  
  // For university domains
  if (hostname.includes('ac.ir') || hostname.includes('edu')) {
    return {
      ...result,
      featured: {
        title: result.title,
        description: result.snippet,
        image: 'https://images.unsplash.com/photo-1576495199011-eb94736d05d6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400',
        attributes: {
          'نوع': 'دانشگاه',
          'وب‌سایت': result.url,
          'محل': 'ایران',
          'نوع': 'دانشگاه دولتی'
        }
      }
    };
  }
  
  // Default - return result without featured snippet
  return result;
}
