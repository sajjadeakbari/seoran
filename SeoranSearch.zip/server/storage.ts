import { 
  users, 
  crawledPages,
  crawlerStats,
  type User, 
  type InsertUser, 
  type CrawledPage, 
  type InsertCrawledPage,
  type CrawlerStats,
  type InsertCrawlerStats
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, like, or, sql, gte } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Crawler methods
  addCrawledPage(page: InsertCrawledPage): Promise<CrawledPage>;
  getCrawledPage(id: string): Promise<CrawledPage | undefined>;
  updateCrawledPage(id: string, page: Partial<InsertCrawledPage>): Promise<CrawledPage | undefined>;
  deleteCrawledPage(id: string): Promise<boolean>;
  
  // Search methods
  searchCrawledPages(query: string, filters: any): Promise<CrawledPage[]>;
  
  // Stats methods
  updateCrawlerStats(stats: Partial<InsertCrawlerStats>): Promise<CrawlerStats>;
  getCrawlerStats(): Promise<CrawlerStats>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }
  
  // Crawler methods
  async addCrawledPage(page: InsertCrawledPage): Promise<CrawledPage> {
    const result = await db.insert(crawledPages).values(page).returning();
    return result[0];
  }
  
  async getCrawledPage(id: string): Promise<CrawledPage | undefined> {
    const result = await db.select().from(crawledPages).where(eq(crawledPages.id, id));
    return result[0];
  }
  
  async updateCrawledPage(id: string, page: Partial<InsertCrawledPage>): Promise<CrawledPage | undefined> {
    const result = await db
      .update(crawledPages)
      .set({ ...page, updatedAt: new Date() })
      .where(eq(crawledPages.id, id))
      .returning();
    
    return result[0];
  }
  
  async deleteCrawledPage(id: string): Promise<boolean> {
    await db.delete(crawledPages).where(eq(crawledPages.id, id));
    return true; // In PostgreSQL, operation succeeds even if no rows affected
  }
  
  // Search methods
  async searchCrawledPages(query: string, filters: any): Promise<CrawledPage[]> {
    let queryBuilder = db.select().from(crawledPages);
    const searchConditions: any[] = [];
    
    // Add search conditions if query is provided
    if (query && query.trim() !== '') {
      const searchTerms = query.toLowerCase().split(/\s+/);
      for (const term of searchTerms) {
        searchConditions.push(
          or(
            like(crawledPages.title, `%${term}%`),
            like(crawledPages.content, `%${term}%`),
            like(crawledPages.description, `%${term}%`)
          )
        );
      }
      
      if (searchConditions.length > 0) {
        queryBuilder = queryBuilder.where(and(...searchConditions));
      }
    }
    
    // Apply filters if provided
    if (filters) {
      // Language filter
      if (filters.language && filters.language !== 'all') {
        queryBuilder = queryBuilder.where(eq(crawledPages.language, filters.language));
      }
      
      // Source filter
      if (filters.source && filters.source !== 'all') {
        queryBuilder = queryBuilder.where(eq(crawledPages.source, filters.source));
      }
      
      // Time filter
      if (filters.time && filters.time !== 'all') {
        const now = new Date();
        let cutoffDate: Date;
        
        switch (filters.time) {
          case '24h':
            cutoffDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
            break;
          case 'week':
            cutoffDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
            break;
          case 'month':
            cutoffDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
            break;
          case 'year':
            cutoffDate = new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000);
            break;
          default:
            cutoffDate = new Date(0); // Beginning of time
        }
        
        queryBuilder = queryBuilder.where(gte(crawledPages.indexedAt, cutoffDate));
      }
    }
    
    // Add sorting
    queryBuilder = queryBuilder.orderBy(desc(crawledPages.indexedAt));
    
    // Execute query
    return await queryBuilder;
  }
  
  // Stats methods
  async updateCrawlerStats(stats: Partial<InsertCrawlerStats>): Promise<CrawlerStats> {
    // Check if a stats record exists
    const existingStatsResult = await db.select().from(crawlerStats).limit(1);
    const existingStats = existingStatsResult[0];
    
    if (existingStats) {
      // Update existing record
      const result = await db
        .update(crawlerStats)
        .set({ ...stats, lastRunAt: stats.lastRunAt || new Date() })
        .where(eq(crawlerStats.id, existingStats.id))
        .returning();
      
      return result[0];
    } else {
      // Create new record
      const result = await db
        .insert(crawlerStats)
        .values({ 
          ...stats, 
          lastRunAt: stats.lastRunAt || new Date()
        })
        .returning();
      
      return result[0];
    }
  }
  
  async getCrawlerStats(): Promise<CrawlerStats> {
    // Try to get the first record
    const result = await db.select().from(crawlerStats).limit(1);
    
    if (result.length === 0) {
      // If no stats exist, create a default one
      return this.updateCrawlerStats({
        pagesIndexed: 0,
        queueSize: 0
      });
    }
    
    return result[0];
  }
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private crawledPages: Map<string, CrawledPage>;
  private crawlerStats: CrawlerStats;
  currentId: number;

  constructor() {
    this.users = new Map();
    this.crawledPages = new Map();
    this.currentId = 1;
    
    // Initialize default crawler stats
    this.crawlerStats = {
      id: 1,
      lastRunAt: new Date(),
      pagesIndexed: 0,
      queueSize: 0
    };
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Crawler methods
  async addCrawledPage(page: InsertCrawledPage): Promise<CrawledPage> {
    const crawledPage: CrawledPage = {
      id: page.id,
      url: page.url,
      title: page.title || null,
      content: page.content || null,
      description: page.description || null,
      language: page.language || null,
      indexedAt: page.indexedAt || new Date(),
      updatedAt: new Date(),
      source: page.source || null
    };
    
    this.crawledPages.set(crawledPage.id, crawledPage);
    return crawledPage;
  }
  
  async getCrawledPage(id: string): Promise<CrawledPage | undefined> {
    return this.crawledPages.get(id);
  }
  
  async updateCrawledPage(id: string, page: Partial<InsertCrawledPage>): Promise<CrawledPage | undefined> {
    const existingPage = this.crawledPages.get(id);
    
    if (!existingPage) {
      return undefined;
    }
    
    const updatedPage: CrawledPage = {
      ...existingPage,
      ...page,
      updatedAt: new Date()
    };
    
    this.crawledPages.set(id, updatedPage);
    return updatedPage;
  }
  
  async deleteCrawledPage(id: string): Promise<boolean> {
    return this.crawledPages.delete(id);
  }
  
  // Search methods
  async searchCrawledPages(query: string, filters: any): Promise<CrawledPage[]> {
    // Simple in-memory search implementation
    const searchTerms = query.toLowerCase().split(/\s+/);
    
    return Array.from(this.crawledPages.values())
      .filter(page => {
        // Check if page matches search terms
        const content = `${page.title} ${page.content} ${page.description}`.toLowerCase();
        const matchesQuery = searchTerms.every(term => content.includes(term));
        
        if (!matchesQuery) return false;
        
        // Apply filters if provided
        if (filters) {
          // Language filter
          if (filters.language !== 'all' && page.language !== filters.language) {
            return false;
          }
          
          // Source filter
          if (filters.source !== 'all' && page.source !== filters.source) {
            return false;
          }
          
          // Time filter
          if (filters.time !== 'all') {
            const now = new Date();
            const pageDate = page.indexedAt ? new Date(page.indexedAt) : now;
            const diffInDays = (now.getTime() - pageDate.getTime()) / (1000 * 60 * 60 * 24);
            
            switch (filters.time) {
              case '24h':
                if (diffInDays > 1) return false;
                break;
              case 'week':
                if (diffInDays > 7) return false;
                break;
              case 'month':
                if (diffInDays > 30) return false;
                break;
              case 'year':
                if (diffInDays > 365) return false;
                break;
            }
          }
        }
        
        return true;
      });
  }
  
  // Stats methods
  async updateCrawlerStats(stats: Partial<InsertCrawlerStats>): Promise<CrawlerStats> {
    this.crawlerStats = {
      ...this.crawlerStats,
      ...stats,
      lastRunAt: stats.lastRunAt || new Date()
    };
    
    return this.crawlerStats;
  }
  
  async getCrawlerStats(): Promise<CrawlerStats> {
    return this.crawlerStats;
  }
}

export const storage = new DatabaseStorage();
