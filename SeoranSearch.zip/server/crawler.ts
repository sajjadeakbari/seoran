import * as cheerio from 'cheerio';
import { storage } from './storage';
import { v4 as uuidv4 } from 'uuid';

// Initial seeds for crawling - using fake domains for testing environment
// In a production environment, these would be real Persian websites
const INITIAL_SEEDS = [
  'https://example.com/fa',
  'https://demo.com/persian',
  'https://test.com/farsi',
];

// Maximum number of pages to crawl in a batch
const MAX_PAGES_PER_BATCH = 50;

// Maximum number of URLs to queue
const MAX_QUEUE_SIZE = 1000;

// Set to track visited URLs to avoid duplicates
const visitedUrls = new Set<string>();

// Queue for URLs to crawl
const urlQueue: string[] = [];

// Add initial seeds to the queue
function initializeQueue() {
  INITIAL_SEEDS.forEach(url => {
    if (!visitedUrls.has(url)) {
      urlQueue.push(url);
      visitedUrls.add(url);
    }
  });
}

// Detect language of the page content
function detectLanguage(text: string): string {
  // Simple language detection based on character sets
  // Persian characters range from U+0600 to U+06FF
  const persianChars = text.replace(/[^\u0600-\u06FF]/g, '').length;
  const totalChars = text.length;
  
  if (persianChars > totalChars * 0.4) {
    return 'fa';
  }
  
  // Basic Arabic detection
  const arabicChars = text.replace(/[^\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/g, '').length;
  if (arabicChars > totalChars * 0.4 && persianChars < totalChars * 0.3) {
    return 'ar';
  }
  
  return 'en';
}

// Extract domain from URL
function extractDomain(url: string): string {
  try {
    const domain = new URL(url).hostname;
    return domain;
  } catch (error) {
    return '';
  }
}

// Determine source type
function determineSourceType(url: string): string {
  const domain = extractDomain(url);
  
  if (domain.includes('ac.ir') || domain.includes('edu')) {
    return 'academic';
  }
  
  if (domain.includes('news') || 
      domain.includes('irna.ir') || 
      domain.includes('isna.ir') || 
      domain.includes('mehrnews') || 
      domain.includes('farsnews')) {
    return 'news';
  }
  
  if (domain.includes('sid.ir') || 
      domain.includes('noormags') || 
      domain.includes('magiran') || 
      domain.includes('civilica')) {
    return 'scientific';
  }
  
  if (domain.includes('blog') || 
      domain.includes('medium') || 
      domain.includes('virgool')) {
    return 'blogs';
  }
  
  return 'general';
}

// Normalize URL
function normalizeUrl(url: string, baseUrl: string): string {
  try {
    // Handle relative URLs
    if (url.startsWith('/')) {
      const base = new URL(baseUrl);
      return `${base.protocol}//${base.host}${url}`;
    }
    
    // Handle URLs without protocol
    if (url.startsWith('//')) {
      const base = new URL(baseUrl);
      return `${base.protocol}${url}`;
    }
    
    // Handle complete URLs
    if (url.startsWith('http')) {
      return url;
    }
    
    // Handle relative URLs without leading slash
    const base = new URL(baseUrl);
    return `${base.protocol}//${base.host}/${url}`;
  } catch (error) {
    return '';
  }
}

// Extract links from a page
function extractLinks(html: string, baseUrl: string): string[] {
  const links: string[] = [];
  const $ = cheerio.load(html);
  
  $('a').each((_, element) => {
    const href = $(element).attr('href');
    if (href) {
      const normalizedUrl = normalizeUrl(href, baseUrl);
      if (normalizedUrl && 
          !normalizedUrl.includes('#') && 
          !normalizedUrl.endsWith('.jpg') && 
          !normalizedUrl.endsWith('.png') && 
          !normalizedUrl.endsWith('.pdf') && 
          !normalizedUrl.endsWith('.mp3') && 
          !normalizedUrl.endsWith('.mp4')) {
        links.push(normalizedUrl);
      }
    }
  });
  
  return links;
}

// Extract main content from HTML
function extractMainContent($: cheerio.CheerioAPI): string {
  // Try to find main content container
  const mainSelectors = [
    'main', 
    'article', 
    '.content', 
    '.post-content', 
    '.entry-content', 
    '#content',
    '[role="main"]',
    '.main-content'
  ];
  
  let mainElement = null;
  for (const selector of mainSelectors) {
    const element = $(selector);
    if (element.length > 0) {
      mainElement = element;
      break;
    }
  }
  
  // If no main container found, collect paragraphs and headings
  if (!mainElement) {
    // Get all paragraphs and headings, ignoring those in headers, footers, navs, asides
    const contentElements = $('body')
      .find('p, h1, h2, h3, h4, h5, h6')
      .filter((_, el) => {
        const parents = $(el).parents('header, footer, nav, aside, .sidebar').length;
        return parents === 0;
      });
    
    const textContent = contentElements
      .map((_, el) => $(el).text().trim())
      .get()
      .filter(text => text.length > 0)
      .join(' ')
      .replace(/\s+/g, ' ');
    
    return textContent || '';
  }
  
  // Clean and get text from main content
  const contentText = mainElement
    .clone()
    .find('script, style, iframe, header, footer, nav, aside, .sidebar, .comments, .ad, .advertisement')
    .remove()
    .end()
    .text()
    .replace(/\s+/g, ' ')
    .trim();
  
  return contentText;
}

// Crawl a specific URL
async function crawlUrl(url: string): Promise<void> {
  try {
    console.log(`Crawling: ${url}`);
    
    // Try to fetch real content if possible
    let html = '';
    let fetchSuccessful = false;
    
    try {
      // Fetch the page with a timeout
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout
      
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'SeoranBot/1.0 (+https://seoran.ir/bot)',
        },
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      
      if (response.ok) {
        html = await response.text();
        fetchSuccessful = true;
      } else {
        console.log(`Failed to fetch ${url}: ${response.status}`);
      }
    } catch (error: any) {
      console.log(`Fetch error for ${url}: ${error.message}`);
    }
    
    // If fetch failed, create dummy data and move on
    if (!fetchSuccessful) {
      // Add a placeholder entry to the database
      try {
        await storage.addCrawledPage({
          id: uuidv4(),
          url,
          title: url,
          content: '',
          description: '',
          language: 'fa',
          indexedAt: new Date(),
          updatedAt: new Date(),
          source: 'general'
        });
        console.log(`Added page to index: ${url} (placeholder)`);
      } catch (error: any) {
        console.error(`Error adding placeholder page to storage: ${error.message}`);
      }
      return;
    }
    
    // Parse HTML
    const $ = cheerio.load(html);
    
    // Extract page metadata
    const title = $('title').text().trim() || extractDomain(url);
    const description = $('meta[name="description"]').attr('content') || 
                       $('meta[property="og:description"]').attr('content') || 
                       '';
    
    // Extract main content
    const content = extractMainContent($);
    
    // Detect language
    const language = detectLanguage(content);
    
    // Determine the source type
    const source = determineSourceType(url);
    
    // Add the current URL to storage
    try {
      await storage.addCrawledPage({
        id: uuidv4(),
        url,
        title,
        content,
        description,
        language,
        indexedAt: new Date(),
        updatedAt: new Date(),
        source
      });
      
      console.log(`Added page to index: ${url}`);
      
      // Generate some demo URLs for testing
      if (urlQueue.length < 5) {
        const demoURLs = [
          'https://demo-seoran.com/news/1',
          'https://demo-seoran.com/news/2',
          'https://demo-seoran.com/blog/persian-literature',
          'https://demo-seoran.com/academic/research',
          'https://demo-seoran.com/shop/books',
        ];
        
        for (const demoURL of demoURLs) {
          if (!visitedUrls.has(demoURL) && urlQueue.length < MAX_QUEUE_SIZE) {
            urlQueue.push(demoURL);
            visitedUrls.add(demoURL);
          }
        }
      }
      
      // Extract links for further crawling
      if (fetchSuccessful) {
        const links = extractLinks(html, url);
        
        // Add new links to the queue - focus on Persian content
        links.forEach(link => {
          if (!visitedUrls.has(link) && urlQueue.length < MAX_QUEUE_SIZE) {
            // Prioritize .ir domains and Persian content
            if (link.includes('.ir/') || 
                link.includes('/fa/') || 
                link.includes('/persian/') || 
                link.includes('/farsi/')) {
              urlQueue.unshift(link); // Add to front of queue
            } else {
              urlQueue.push(link); // Add to end of queue
            }
            visitedUrls.add(link);
          }
        });
      }
    } catch (error: any) {
      console.error(`Error adding page to storage: ${error.message}`);
    }
  } catch (error: any) {
    console.error(`Error crawling ${url}:`, error.message);
  }
}

// Start a crawling batch
async function crawlBatch(): Promise<void> {
  console.log(`Queue size: ${urlQueue.length}, Visited: ${visitedUrls.size}`);
  
  if (urlQueue.length === 0) {
    console.log('Queue is empty. Reinitializing...');
    initializeQueue();
    return;
  }
  
  const batchSize = Math.min(MAX_PAGES_PER_BATCH, urlQueue.length);
  const batch = urlQueue.splice(0, batchSize);
  
  // Process batch concurrently with rate limiting
  const promises = batch.map((url, index) => {
    return new Promise<void>(resolve => {
      setTimeout(() => {
        crawlUrl(url)
          .catch(err => console.error(`Batch crawl error for ${url}:`, err))
          .finally(() => resolve());
      }, index * 1000); // 1 second delay between requests
    });
  });
  
  await Promise.all(promises);
  
  // Update crawler statistics
  try {
    await storage.updateCrawlerStats({
      lastRunAt: new Date(),
      pagesIndexed: visitedUrls.size,
      queueSize: urlQueue.length
    });
  } catch (error: any) {
    console.error("Error updating crawler stats:", error.message);
  }
}

// Start the crawler
export function startCrawler(): void {
  console.log('Starting crawler...');
  initializeQueue();
  crawlBatch().catch(console.error);
}

// Schedule periodic crawling
export function scheduleCrawling(): void {
  // Run a crawl batch every 5 minutes
  setInterval(() => {
    crawlBatch().catch(console.error);
  }, 5 * 60 * 1000);
}